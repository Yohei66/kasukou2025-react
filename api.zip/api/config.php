<?php
/**
 * 設定ファイルの記入例。
 *
 * 【使い方】
 *  1. このファイルをコピーして「config.php」という名前で保存する
 *  2. 下の値を、契約したサーバーの実際の値に書き換える
 *  3. サーバーにアップロードする
 *
 * 【置き場所】
 *  公開ディレクトリ（public_html）の外に置くのが安全。
 *    public_html/api/    ← プログラム
 *    config.php          ← ここ（public_html と同じ階層）
 *
 *  サーバーの都合で外に置けない場合は public_html/api/config.php でも動く。
 *
 * 【注意】
 *  このファイルの中身はパスワードそのもの。Git には入れないこと（.gitignore 済み）。
 */

return [
    // ---- データベース ----
    // レンタルサーバーの管理画面「データベース設定」で作成した値を入れる。
    // DB_HOST はサーバーによって異なる（localhost のこともあれば専用のホスト名のこともある）。
    'DB_HOST'     => 'localhost',
    'DB_NAME'     => 'testkasukou',
    'DB_USER'     => 'testkasukou',
    'DB_PASSWORD' => 'password',

    // ---- 管理者ログイン（管理者は1人） ----
    // 試験用サーバーと本番サーバーで別のパスワードにすること。
    'ADMIN_USER'     => 'admin',
    'ADMIN_PASSWORD' => 'testpass',

    // ---- コート中止連絡の合言葉（会員が中止登録するときに入力する） ----
    'CANCEL_PASSWORD' => 'candelpass',

    // ---- 問い合わせフォームの通知メール ----
    // 両方そろって初めてメールが送られる。空ならDBに保存されるだけ。
    // CONTACT_FROM はサーバーのドメインのアドレスにする（SPFで弾かれないため）。
    // 試験用サーバーでは CONTACT_TO を自分のアドレスにしておくこと。
    'CONTACT_TO'   => 'ruiyouhei6@gmail.com',
    'CONTACT_FROM' => 'no-reply@testkasukou.xrea.com',   // ← XREAのURLのドメイン部分

];
